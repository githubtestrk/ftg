#!/bin/bash
./ocserv-install-script-for-centos7.sh